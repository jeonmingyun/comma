package com.org.ticketzone.app_mem.vo;

import lombok.Data;

@Data
public class CoordinatesVO {
    private String coor_x;
    private String coor_y;
    private String license_number;
    private String store_name;
    private String distance;
    private String my_x;
    private String my_y;
}
