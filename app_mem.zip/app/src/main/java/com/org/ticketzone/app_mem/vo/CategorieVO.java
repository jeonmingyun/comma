package com.org.ticketzone.app_mem.vo;

import lombok.Data;

@Data
public class CategorieVO {
	private String cate_code;
	private String cate_name;
}
