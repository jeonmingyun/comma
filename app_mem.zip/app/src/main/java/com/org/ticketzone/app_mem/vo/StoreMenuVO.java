package com.org.ticketzone.app_mem.vo;

import lombok.Data;

@Data
public class StoreMenuVO {
	private String menu_code;
	private String menu_name;
	private String menu_price;
	private String store_note;
}
