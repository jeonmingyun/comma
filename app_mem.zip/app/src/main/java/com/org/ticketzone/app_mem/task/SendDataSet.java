package com.org.ticketzone.app_mem.task;

public class SendDataSet {
    String key, value;

    public SendDataSet(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
