package com.org.ticketzone.app_mem.vo;

import lombok.Data;

@Data
public class BeaconVO {
    private String b_code;
    private String store_name;
    private String license_number;
}
